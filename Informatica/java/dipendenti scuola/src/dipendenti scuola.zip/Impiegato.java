import java.time.LocalDate;

public class Impiegato extends Dipendente {
	
	private int livello;
	private final int retribuzioneOraria=8;
	
	public Impiegato(String nominativo, String sesso, LocalDate dataDiNascita, double stipendioBase,
			double straordinario, int livello) {
		super(nominativo, sesso, dataDiNascita, stipendioBase, straordinario);
		this.livello = livello;
	}

	public int getLivello() {
		return livello;
	}

	public void setLivello(int livello) {
		this.livello = livello;
	}

	public int getRetribuzioneOraria() {
		return retribuzioneOraria;
	}

	@Override
	public String toString() {
		return "livello=" + livello + "  retribuzioneOraria=" + retribuzioneOraria + "  toString()=" + super.toString()
				+ " ";
	}

	@Override
	public double straordinario(int ore) {
		setStraordinario(ore*retribuzioneOraria);
		return getStraordinario();
	}

	@Override
	public double stipendioMensile() {
		return getStipendioBase() + getStraordinario();
	}
	
	
	

}
